import { useState, useMemo, useRef, useEffect } from 'react'
import {
  APP_CATALOGUE,
  TWEAK_CATALOGUE,
  generatePSScript,
  type AppItem,
  type TweakItem,
} from './psScript'

// ── Types ─────────────────────────────────────────────────────────────────────
type Tab = 'install' | 'tweaks' | 'gaming' | 'config' | 'updates' | 'microwin'
type UpdatePolicy = 'default' | 'security' | 'disable'

interface LogEntry {
  id: number
  type: 'INFO' | 'OK' | 'WARN' | 'ERR' | 'ACTION'
  msg: string
  ts: string
}

// ── Colour tokens (Cyber Blue) ────────────────────────────────────────────────
const C = {
  bg:       '#000B1A',
  surface:  '#001F3F',
  surface2: '#003366',
  accent:   '#00D9FF',
  navBg:    '#000814',
  textDim:  '#8090A0',
  border:   '#002A4A',
  logBg:    '#00050A',
  text:     '#E8F0F8',
  ok:       '#00FF88',
  warn:     '#FFB800',
  err:      '#FF4466',
}

// ── Tweak groups ──────────────────────────────────────────────────────────────
const GROUPS = ['General','RAM','Power','CPU/GPU','Gaming','Network','Input','Cleanup','Debloat']

// ── Gaming module cards ───────────────────────────────────────────────────────
const GAMING_CARDS = [
  { id:'zero_latency',   icon:'⚡', title:'Zero Latency',         badge:'BCD+Registry', color:'#FFB800',
    desc:'Enables useplatformtick, disabledynamictick, sets Win32PrioritySeparation=0x26 and disables Nagle\'s Algorithm. Eliminates micro-stutters and online input lag.',
    tweaks:['platform_tick','win32_priority','disable_nagle'] },
  { id:'game_booster',   icon:'🚀', title:'Game Booster',          badge:'Multimedia',   color:'#00FF88',
    desc:'Sets NetworkThrottlingIndex=0xFFFFFFFF and SystemResponsiveness=10. Tells Windows to treat your game as the highest-priority multimedia task.',
    tweaks:['net_throttle_off','mmu_gaming','game_mode'] },
  { id:'ultimate_power', icon:'👑', title:'Ultimate Performance',  badge:'Power Plan',   color:'#FFD700',
    desc:'Unlocks the hidden Ultimate Performance power plan (e9a42b02...) that disables ALL core parking and C-states for maximum sustained CPU clock speed.',
    tweaks:['ultimate_perf','disable_core_park'] },
  { id:'gpu_tweak',      icon:'🖥️', title:'GPU Scheduling (HAGS)', badge:'DirectX',      color:'#BF5FFF',
    desc:'Sets HwSchMode=2 to enable Hardware Accelerated GPU Scheduling. Reduces CPU overhead when managing GPU memory, improving frame-time consistency.',
    tweaks:['gpu_sched'] },
  { id:'health_scan',    icon:'🏥', title:'System Health Scan',    badge:'SFC+DISM',     color:'#00D9FF',
    desc:'Runs SFC /scannow to fix corrupted files, DISM /RestoreHealth to download fresh system components, then purges the Windows Update cache.',
    tweaks:[] },
  { id:'storage_opt',    icon:'💾', title:'Storage Optimizer',     badge:'NTFS+TRIM',    color:'#FF6B35',
    desc:'Enables SSD TRIM, disables 8.3 short filenames and last-access timestamps. Reduces unnecessary NTFS write I/O for faster disk performance.',
    tweaks:['trim_ssd','disable_83names','disable_lastaccess'] },
]

// ── Config shortcuts ──────────────────────────────────────────────────────────
const CONFIG_CARDS = [
  { icon:'🎨', title:'Personalisation',    ms:'ms-settings:personalization',         desc:'Open the Personalization settings panel — themes, colours, lock screen.' },
  { icon:'🔒', title:'Security & Privacy', ms:'ms-settings:privacy',                 desc:'Manage app permissions, privacy settings, and Windows Security.' },
  { icon:'🖥️', title:'Display Settings',   ms:'ms-settings:display',                 desc:'Resolution, refresh rate, HDR, multiple monitor arrangement.' },
  { icon:'⚡', title:'Power & Sleep',       ms:'ms-settings:powersleep',              desc:'Battery / power plan settings, screen timeout, sleep settings.' },
  { icon:'🗑️', title:'Disk Cleanup',        ms:'cleanmgr',                            desc:'Launch built-in Disk Cleanup to safely delete junk files.' },
  { icon:'📋', title:'Task Manager',        ms:'taskmgr',                             desc:'Open Task Manager to monitor CPU, RAM, disk, and network usage.' },
  { icon:'🌐', title:'Network Settings',    ms:'ms-settings:network',                 desc:'Wi-Fi, Ethernet, VPN, and network adapter configuration.' },
  { icon:'🔄', title:'Windows Update',      ms:'ms-settings:windowsupdate',           desc:'Check for and install Windows updates manually.' },
  { icon:'🖱️', title:'Mouse Settings',      ms:'ms-settings:mousetouchpad',           desc:'Pointer speed, scroll direction, button configuration.' },
  { icon:'🔊', title:'Sound Settings',      ms:'ms-settings:sound',                   desc:'Output device, volume, microphone, spatial audio settings.' },
  { icon:'📱', title:'Apps & Features',     ms:'ms-settings:appsfeatures',            desc:'Uninstall or manage installed apps and optional features.' },
  { icon:'🛡️', title:'Windows Defender',    ms:'windowsdefender:',                    desc:'Open Windows Security — virus protection, firewall, and more.' },
]

// ── Update policy options ──────────────────────────────────────────────────────
const UPDATE_OPTIONS: { id: UpdatePolicy; icon: string; title: string; sub: string; color: string; desc: string }[] = [
  { id:'default',  icon:'✅', title:'Default (Recommended)', sub:'Auto download & install',    color:C.ok,   desc:'Windows will automatically download and install all updates including security patches, drivers, and feature updates. This is the safest option.' },
  { id:'security', icon:'🔒', title:'Security Only',         sub:'Manual control, patches only',color:C.warn, desc:'Sets AU policy to notify-only. You manually approve updates, but critical security patches are still available. Good balance of control and safety.' },
  { id:'disable',  icon:'⛔', title:'Disable Updates',       sub:'Not recommended',            color:C.err,  desc:'Completely disables Windows Update service. Your system will NOT receive security patches. Only use if you manage updates manually via WSUS or SCCM.' },
]

// ── Low-End Macro tweak IDs ───────────────────────────────────────────────────
const LOW_END_IDS = TWEAK_CATALOGUE.filter(t => t.lowEnd).map(t => t.id)

// ── Helpers ───────────────────────────────────────────────────────────────────
let logSeq = 0
function mkLog(type: LogEntry['type'], msg: string): LogEntry {
  const now = new Date()
  return {
    id: ++logSeq,
    type,
    msg,
    ts: `${now.getHours().toString().padStart(2,'0')}:${now.getMinutes().toString().padStart(2,'0')}:${now.getSeconds().toString().padStart(2,'0')}`,
  }
}

const LOG_COLOURS: Record<LogEntry['type'], string> = {
  INFO:   C.accent,
  OK:     C.ok,
  WARN:   C.warn,
  ERR:    C.err,
  ACTION: '#BF5FFF',
}

// ── Main App ──────────────────────────────────────────────────────────────────
export default function App() {
  const [tab, setTab]                     = useState<Tab>('install')
  const [apps, setApps]                   = useState<AppItem[]>(APP_CATALOGUE.map(a => ({ ...a, checked: false })))
  const [tweaks, setTweaks]               = useState<TweakItem[]>(TWEAK_CATALOGUE.map(t => ({ ...t, checked: false })))
  const [updatePolicy, setUpdatePolicy]   = useState<UpdatePolicy>('default')
  const [restoreCreated, setRestoreCreated] = useState(false)
  const [logs, setLogs]                   = useState<LogEntry[]>([mkLog('INFO', "Ray's Optimization Chamber v3.0 — Ready. Select your optimizations and generate the script.")])
  const [scriptModal, setScriptModal]     = useState(false)
  const [scriptText, setScriptText]       = useState('')
  const [appSearch, setAppSearch]         = useState('')
  const [appCatFilter, setAppCatFilter]   = useState('All')
  const [tweakGroup, setTweakGroup]       = useState('General')
  const [gamingSelected, setGamingSelected] = useState<string[]>([])
  const [microwinEnabled, setMicrowinEnabled] = useState(false)
  const [microwinOpts, setMicrowinOpts]   = useState({ removeXbox:true, removeOneDrive:true, removeTeams:true, removeBloat:true, disableDefender:false, addNET3:false, disableTelemetry:true })
  const [updateWarning, setUpdateWarning] = useState(false)
  const logEndRef = useRef<HTMLDivElement>(null)

  const addLog = (type: LogEntry['type'], msg: string) =>
    setLogs(prev => [...prev.slice(-199), mkLog(type, msg)])

  useEffect(() => { logEndRef.current?.scrollIntoView({ behavior: 'smooth' }) }, [logs])

  // ── Derived ────────────────────────────────────────────────────────────────
  const selectedApps   = apps.filter(a => a.checked)
  const selectedTweaks = tweaks.filter(t => t.checked).map(t => t.id)
  const appCategories  = ['All', ...Array.from(new Set(APP_CATALOGUE.map(a => a.category)))]

  const visibleApps = useMemo(() => apps.filter(a => {
    const matchSearch = a.name.toLowerCase().includes(appSearch.toLowerCase()) || a.winget.toLowerCase().includes(appSearch.toLowerCase())
    const matchCat    = appCatFilter === 'All' || a.category === appCatFilter
    return matchSearch && matchCat
  }), [apps, appSearch, appCatFilter])

  const groupedTweaks = useMemo(() =>
    tweaks.filter(t => t.group === tweakGroup), [tweaks, tweakGroup])

  // ── Handlers ───────────────────────────────────────────────────────────────
  const toggleApp = (id: string) => {
    setApps(prev => prev.map(a => a.id === id ? { ...a, checked: !a.checked } : a))
    const app = apps.find(a => a.id === id)
    if (app) addLog('INFO', `${app.checked ? 'Deselected' : 'Selected'}: ${app.name}`)
  }

  const selectAllVisible = () => {
    const ids = new Set(visibleApps.map(a => a.id))
    setApps(prev => prev.map(a => ids.has(a.id) ? { ...a, checked: true } : a))
    addLog('INFO', `Selected all ${visibleApps.length} visible apps`)
  }
  const clearApps = () => {
    setApps(prev => prev.map(a => ({ ...a, checked: false })))
    addLog('INFO', 'Cleared all app selections')
  }

  const toggleTweak = (id: string) => {
    if (!restoreCreated && id !== 'net_refresh') {
      addLog('WARN', 'Create a Restore Point first before enabling tweaks!')
      return
    }
    setTweaks(prev => prev.map(t => t.id === id ? { ...t, checked: !t.checked } : t))
    const tweak = tweaks.find(t => t.id === id)
    if (tweak) addLog('INFO', `${tweak.checked ? 'Disabled' : 'Enabled'}: ${tweak.label}`)
  }

  const applyLowEnd = () => {
    if (!restoreCreated) { addLog('WARN', 'Create a Restore Point before applying tweaks!'); return }
    setTweaks(prev => prev.map(t => ({ ...t, checked: LOW_END_IDS.includes(t.id) ? true : t.checked })))
    addLog('OK', `Low-End PC Macro applied — ${LOW_END_IDS.length} safe optimizations selected`)
  }

  const revertAll = () => {
    setTweaks(prev => prev.map(t => ({ ...t, checked: false })))
    setGamingSelected([])
    addLog('WARN', 'All tweaks deselected. Generate script to apply Revert-AllChanges PowerShell function.')
    addLog('ACTION', 'The generated script will include Revert-AllChanges() to restore Windows defaults.')
  }

  const createRestorePoint = () => {
    setRestoreCreated(true)
    addLog('ACTION', 'Restore Point creation queued — will run first when script executes.')
    addLog('OK', 'Tweaks are now unlocked. Proceed with your optimizations.')
  }

  const toggleGaming = (id: string, tweakIds: string[]) => {
    if (!restoreCreated) { addLog('WARN', 'Create a Restore Point before enabling gaming tweaks!'); return }
    const active = gamingSelected.includes(id)
    if (active) {
      setGamingSelected(prev => prev.filter(x => x !== id))
      setTweaks(prev => prev.map(t => tweakIds.includes(t.id) ? { ...t, checked: false } : t))
      addLog('INFO', `Disabled gaming module: ${id}`)
    } else {
      setGamingSelected(prev => [...prev, id])
      setTweaks(prev => prev.map(t => tweakIds.includes(t.id) ? { ...t, checked: true } : t))
      addLog('OK', `Enabled gaming module: ${id}`)
    }
  }

  const generateScript = () => {
    const allTweakIds = [
      ...selectedTweaks,
      ...(gamingSelected.includes('health_scan') ? [] : []),
    ]
    const script = generatePSScript(apps, allTweakIds, updatePolicy, microwinEnabled)
    setScriptText(script)
    setScriptModal(true)
    addLog('OK', `Script generated — ${script.split('\n').length} lines`)
    addLog('INFO', `Apps: ${selectedApps.length} | Tweaks: ${allTweakIds.length} | Update: ${updatePolicy} | MicroWin: ${microwinEnabled}`)
  }

  const downloadScript = () => {
    const blob = new Blob([scriptText], { type: 'text/plain' })
    const url  = URL.createObjectURL(blob)
    const a    = document.createElement('a')
    a.href = url; a.download = 'RaysOptimizationChamber.ps1'; a.click()
    URL.revokeObjectURL(url)
    addLog('OK', 'RaysOptimizationChamber.ps1 downloaded — Run as Administrator!')
  }

  const copyScript = () => {
    navigator.clipboard.writeText(scriptText)
    addLog('OK', 'Script copied to clipboard')
  }

  // ── NAV TABS ───────────────────────────────────────────────────────────────
  const TABS: { id: Tab; icon: string; label: string }[] = [
    { id:'install',  icon:'📦', label:'Install'  },
    { id:'tweaks',   icon:'🔧', label:'Tweaks'   },
    { id:'gaming',   icon:'🎮', label:'Gaming'   },
    { id:'config',   icon:'⚙️', label:'Config'   },
    { id:'updates',  icon:'🔄', label:'Updates'  },
    { id:'microwin', icon:'💿', label:'MicroWin' },
  ]

  // ── Shared styles ──────────────────────────────────────────────────────────
  const cardBase = `rounded-lg border p-4 transition-all duration-200 cursor-pointer select-none`

  // ── RENDER ─────────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col h-screen overflow-hidden font-mono text-sm"
         style={{ background: C.bg, color: C.text }}>

      {/* ── TITLE BAR ── */}
      <header className="flex items-center gap-3 px-6 py-3 border-b shrink-0"
              style={{ background: C.navBg, borderColor: C.border }}>
        <div className="flex items-center gap-2">
          <span className="text-2xl">⚡</span>
          <div>
            <div className="font-bold text-base tracking-wide" style={{ color: C.accent }}>
              Ray's Optimization Chamber
            </div>
            <div className="text-xs" style={{ color: C.textDim }}>WinUtil Pro v3.0 — Cyber Edition</div>
          </div>
        </div>
        <div className="ml-auto flex items-center gap-3 flex-wrap">
          {/* Status pills */}
          <span className="px-2 py-0.5 rounded text-xs font-semibold" style={{ background: C.surface, color: C.accent }}>
            📦 {selectedApps.length} apps
          </span>
          <span className="px-2 py-0.5 rounded text-xs font-semibold" style={{ background: C.surface, color: C.ok }}>
            🔧 {selectedTweaks.length + gamingSelected.reduce((n,id) => n + (GAMING_CARDS.find(g=>g.id===id)?.tweaks.length||0), 0)} tweaks
          </span>
          <span className="px-2 py-0.5 rounded text-xs font-semibold"
                style={{ background: C.surface, color: restoreCreated ? C.ok : C.warn }}>
            {restoreCreated ? '🛡️ Protected' : '⚠️ No Restore Point'}
          </span>
          <button onClick={generateScript}
                  className="px-4 py-1.5 rounded font-bold text-xs transition-all hover:scale-105 active:scale-95"
                  style={{ background: C.accent, color: C.bg }}>
            ▶ Generate Script
          </button>
        </div>
      </header>

      {/* ── NAV TABS ── */}
      <nav className="flex gap-1 px-4 py-2 border-b shrink-0"
           style={{ background: C.navBg, borderColor: C.border }}>
        {TABS.map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
                  className="px-4 py-2 rounded text-xs font-semibold transition-all duration-150"
                  style={{
                    background: tab === t.id ? C.surface2 : 'transparent',
                    color:      tab === t.id ? C.accent   : C.textDim,
                    border:     `1px solid ${tab === t.id ? C.accent : 'transparent'}`,
                    boxShadow:  tab === t.id ? `0 0 12px rgba(0,217,255,0.3)` : 'none',
                  }}>
            {t.icon} {t.label}
          </button>
        ))}
      </nav>

      {/* ── MAIN CONTENT ── */}
      <main className="flex-1 overflow-y-auto p-4" style={{ background: C.bg }}>

        {/* ════════════════════════ INSTALL ════════════════════════ */}
        {tab === 'install' && (
          <div>
            <SectionHeader icon="📦" title="App Installer" sub={`Select apps to install via winget — ${selectedApps.length} selected`} />
            {/* Controls */}
            <div className="flex flex-wrap gap-2 mb-4">
              <input value={appSearch} onChange={e => setAppSearch(e.target.value)}
                     placeholder="🔍 Search apps or winget ID..."
                     className="flex-1 min-w-[200px] px-3 py-2 rounded border text-sm"
                     style={{ background: C.surface, borderColor: C.border, color: C.text }} />
              {appCategories.map(cat => (
                <button key={cat} onClick={() => setAppCatFilter(cat)}
                        className="px-3 py-1.5 rounded text-xs font-semibold transition-all"
                        style={{
                          background: appCatFilter === cat ? C.surface2 : C.surface,
                          color:      appCatFilter === cat ? C.accent    : C.textDim,
                          border:     `1px solid ${appCatFilter === cat ? C.accent : C.border}`,
                        }}>
                  {cat}
                </button>
              ))}
              <button onClick={selectAllVisible} className="px-3 py-1.5 rounded text-xs font-semibold border transition-all hover:brightness-110"
                      style={{ background: C.surface, borderColor: C.border, color: C.ok }}>
                ✓ Select All
              </button>
              <button onClick={clearApps} className="px-3 py-1.5 rounded text-xs font-semibold border transition-all hover:brightness-110"
                      style={{ background: C.surface, borderColor: C.border, color: C.err }}>
                ✕ Clear
              </button>
            </div>
            {/* Grid */}
            <div className="grid gap-2" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(230px, 1fr))' }}>
              {visibleApps.map(app => (
                <div key={app.id} title={`${app.desc}\n\nwinget ID: ${app.winget}`}
                     onClick={() => toggleApp(app.id)}
                     className={`${cardBase} flex items-center gap-3`}
                     style={{
                       background:  app.checked ? C.surface2 : C.surface,
                       borderColor: app.checked ? C.accent    : C.border,
                       boxShadow:   app.checked ? `0 0 10px rgba(0,217,255,0.25)` : 'none',
                     }}>
                  <div className="w-5 h-5 rounded flex items-center justify-center border shrink-0 transition-all"
                       style={{ borderColor: app.checked ? C.accent : C.border, background: app.checked ? C.accent : 'transparent' }}>
                    {app.checked && <span className="text-xs font-bold" style={{ color: C.bg }}>✓</span>}
                  </div>
                  <div className="min-w-0">
                    <div className="font-semibold truncate" style={{ color: app.checked ? C.accent : C.text }}>{app.name}</div>
                    <div className="text-xs truncate" style={{ color: C.textDim }}>{app.category} · {app.winget}</div>
                  </div>
                </div>
              ))}
              {visibleApps.length === 0 && (
                <div className="col-span-full text-center py-10" style={{ color: C.textDim }}>
                  No apps match your search.
                </div>
              )}
            </div>
          </div>
        )}

        {/* ════════════════════════ TWEAKS ════════════════════════ */}
        {tab === 'tweaks' && (
          <div>
            <SectionHeader icon="🔧" title="System Tweaks" sub="Hover over any tweak for a detailed description" />

            {/* Restore Point Guard */}
            <div className="mb-4 p-4 rounded-lg border"
                 style={{ background: restoreCreated ? 'rgba(0,255,136,0.05)' : 'rgba(255,184,0,0.07)', borderColor: restoreCreated ? C.ok : C.warn }}>
              <div className="flex items-center justify-between flex-wrap gap-3">
                <div>
                  <div className="font-bold" style={{ color: restoreCreated ? C.ok : C.warn }}>
                    {restoreCreated ? '🛡️ System Protected — Tweaks Unlocked' : '⚠️ Safety First: Create a Restore Point'}
                  </div>
                  <div className="text-xs mt-0.5" style={{ color: C.textDim }}>
                    {restoreCreated
                      ? 'A restore point will be created when the script runs. You can undo all changes via System Restore.'
                      : 'A system restore point will be created before any changes. Required before enabling tweaks.'}
                  </div>
                </div>
                {!restoreCreated && (
                  <button onClick={createRestorePoint}
                          className="px-5 py-2 rounded font-bold text-sm transition-all hover:scale-105"
                          style={{ background: C.warn, color: '#000' }}>
                    🛡️ Create Restore Point
                  </button>
                )}
              </div>
            </div>

            {/* Macro buttons */}
            <div className="flex flex-wrap gap-2 mb-4">
              <button onClick={applyLowEnd} title="Automatically selects the safest, most impactful tweaks for low-end or older PCs"
                      className="px-4 py-2 rounded font-bold text-xs border transition-all hover:scale-105"
                      style={{ background: 'rgba(0,217,255,0.1)', borderColor: C.accent, color: C.accent }}>
                💻 Low-End PC Macro
              </button>
              <button onClick={revertAll} title="Deselects all tweaks and adds Revert-AllChanges() to the generated script"
                      className="px-4 py-2 rounded font-bold text-xs border transition-all hover:scale-105"
                      style={{ background: 'rgba(255,68,102,0.1)', borderColor: C.err, color: C.err }}>
                ↩ Revert All Changes
              </button>
            </div>

            {/* Group tabs */}
            <div className="flex flex-wrap gap-1 mb-4">
              {GROUPS.map(g => {
                const count = tweaks.filter(t => t.group === g && t.checked).length
                return (
                  <button key={g} onClick={() => setTweakGroup(g)}
                          className="px-3 py-1.5 rounded text-xs font-semibold transition-all"
                          style={{
                            background: tweakGroup === g ? C.surface2 : C.surface,
                            color:      tweakGroup === g ? C.accent    : C.textDim,
                            border:     `1px solid ${tweakGroup === g ? C.accent : C.border}`,
                          }}>
                    {g} {count > 0 && <span className="ml-1 px-1 rounded" style={{ background: C.accent, color: C.bg }}>{count}</span>}
                  </button>
                )
              })}
            </div>

            {/* Tweak grid */}
            <div className="grid gap-2" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))' }}>
              {groupedTweaks.map(tweak => (
                <div key={tweak.id}
                     title={tweak.desc}
                     onClick={() => toggleTweak(tweak.id)}
                     className={`${cardBase} group`}
                     style={{
                       background:  tweak.checked ? C.surface2 : C.surface,
                       borderColor: tweak.checked ? C.accent    : C.border,
                       boxShadow:   tweak.checked ? `0 0 14px rgba(0,217,255,0.35)` : 'none',
                       opacity:     !restoreCreated ? 0.5 : 1,
                     }}>
                  <div className="flex items-start gap-3">
                    <div className="w-5 h-5 rounded border mt-0.5 shrink-0 flex items-center justify-center transition-all"
                         style={{ borderColor: tweak.checked ? C.accent : C.border, background: tweak.checked ? C.accent : 'transparent' }}>
                      {tweak.checked && <span className="text-xs font-bold" style={{ color: C.bg }}>✓</span>}
                    </div>
                    <div>
                      <div className="font-semibold text-sm" style={{ color: tweak.checked ? C.accent : C.text }}>
                        {tweak.label}
                        {tweak.lowEnd && <span className="ml-2 text-xs px-1 rounded" style={{ background: 'rgba(0,217,255,0.15)', color: C.accent }}>💻 Low-End</span>}
                      </div>
                      <div className="text-xs mt-0.5 flex items-center gap-1">
                        <span className="px-1.5 py-0.5 rounded" style={{ background: C.surface, color: C.textDim }}>
                          {tweak.tag}
                        </span>
                      </div>
                      <div className="text-xs mt-1.5 leading-relaxed transition-colors" style={{ color: C.textDim }}>
                        {tweak.desc}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ════════════════════════ GAMING ════════════════════════ */}
        {tab === 'gaming' && (
          <div>
            <SectionHeader icon="🎮" title="Zero Latency Gaming Modules" sub="Esports-grade optimizations — hover for details, click to enable" />

            {!restoreCreated && (
              <div className="mb-4 p-3 rounded-lg border text-sm" style={{ borderColor: C.warn, background: 'rgba(255,184,0,0.07)', color: C.warn }}>
                ⚠️ Create a Restore Point in the Tweaks tab before enabling gaming modules.
              </div>
            )}

            <div className="grid gap-4" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))' }}>
              {GAMING_CARDS.map(card => {
                const active = gamingSelected.includes(card.id)
                return (
                  <div key={card.id} title={card.desc}
                       onClick={() => toggleGaming(card.id, card.tweaks)}
                       className={`${cardBase} cursor-pointer`}
                       style={{
                         background:  active ? `${C.surface2}` : C.surface,
                         borderColor: active ? card.color       : C.border,
                         boxShadow:   active ? `0 0 20px ${card.color}44` : 'none',
                         opacity:     !restoreCreated ? 0.5 : 1,
                       }}>
                    <div className="flex items-start justify-between mb-2">
                      <span className="text-3xl">{card.icon}</span>
                      <div className="flex flex-col items-end gap-1">
                        <span className="text-xs px-2 py-0.5 rounded font-semibold"
                              style={{ background: `${card.color}22`, color: card.color, border: `1px solid ${card.color}44` }}>
                          {card.badge}
                        </span>
                        {active && <span className="text-xs font-bold" style={{ color: C.ok }}>● ACTIVE</span>}
                      </div>
                    </div>
                    <div className="font-bold text-sm mb-1" style={{ color: active ? card.color : C.text }}>
                      {card.title}
                    </div>
                    <div className="text-xs leading-relaxed" style={{ color: C.textDim }}>
                      {card.desc}
                    </div>
                    {card.tweaks.length > 0 && (
                      <div className="mt-2 flex flex-wrap gap-1">
                        {card.tweaks.map(tid => (
                          <span key={tid} className="text-xs px-1.5 py-0.5 rounded"
                                style={{ background: C.surface, color: C.textDim, border: `1px solid ${C.border}` }}>
                            {tid.replace(/_/g,' ')}
                          </span>
                        ))}
                      </div>
                    )}
                  </div>
                )
              })}
            </div>

            {/* BCDEdit info */}
            <div className="mt-6 p-4 rounded-lg border" style={{ background: C.surface, borderColor: C.border }}>
              <div className="font-bold mb-2" style={{ color: C.accent }}>📋 Commands Applied by Gaming Modules</div>
              <div className="text-xs font-mono space-y-1" style={{ color: C.textDim }}>
                <div><span style={{ color: C.ok }}>Zero Latency:</span> bcdedit /set useplatformtick yes · bcdedit /set disabledynamictick yes · Win32PrioritySeparation=0x26 · TcpAckFrequency=1</div>
                <div><span style={{ color: C.ok }}>Game Booster:</span> NetworkThrottlingIndex=0xFFFFFFFF · SystemResponsiveness=10 · AutoGameModeEnabled=1</div>
                <div><span style={{ color: C.ok }}>Ultimate Perf:</span> powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61 · ValueMax=0 (core parking)</div>
                <div><span style={{ color: C.ok }}>HAGS:</span> HwSchMode=2 (HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers)</div>
                <div><span style={{ color: C.ok }}>Health Scan:</span> sfc /scannow · DISM /Online /Cleanup-Image /RestoreHealth · WU cache purge</div>
                <div><span style={{ color: C.ok }}>Storage:</span> fsutil behavior set DisableDeleteNotify 0 · Disable8dot3 1 · disablelastaccess 1</div>
              </div>
            </div>
          </div>
        )}

        {/* ════════════════════════ CONFIG ════════════════════════ */}
        {tab === 'config' && (
          <div>
            <SectionHeader icon="⚙️" title="System Configuration" sub="Quick-launch Windows settings panels and tools" />
            <div className="grid gap-3" style={{ gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))' }}>
              {CONFIG_CARDS.map(c => (
                <div key={c.ms} title={c.desc}
                     onClick={() => addLog('ACTION', `Opening: ${c.title} (${c.ms}) — copy to Run dialog`)}
                     className={`${cardBase} hover:scale-[1.02] group`}
                     style={{ background: C.surface, borderColor: C.border }}>
                  <div className="text-2xl mb-2">{c.icon}</div>
                  <div className="font-bold text-sm mb-1 group-hover:text-cyan-300 transition-colors"
                       style={{ color: C.text }}>{c.title}</div>
                  <div className="text-xs" style={{ color: C.textDim }}>{c.desc}</div>
                  <div className="mt-2 text-xs px-2 py-1 rounded font-mono"
                       style={{ background: C.surface2, color: C.accent, border: `1px solid ${C.border}` }}>
                    {c.ms}
                  </div>
                </div>
              ))}
            </div>

            {/* MicroWin shortcut */}
            <div className="mt-6 p-4 rounded-lg border cursor-pointer hover:scale-[1.01] transition-all"
                 onClick={() => setTab('microwin')}
                 style={{ background: C.surface, borderColor: C.accent }}>
              <div className="flex items-center gap-3">
                <span className="text-3xl">💿</span>
                <div>
                  <div className="font-bold" style={{ color: C.accent }}>MicroWin — ISO Debloater</div>
                  <div className="text-xs mt-0.5" style={{ color: C.textDim }}>
                    Strip bloatware from a Windows ISO file before installation. Click to open MicroWin tab.
                  </div>
                </div>
                <span className="ml-auto text-lg" style={{ color: C.accent }}>→</span>
              </div>
            </div>
          </div>
        )}

        {/* ════════════════════════ UPDATES ════════════════════════ */}
        {tab === 'updates' && (
          <div>
            <SectionHeader icon="🔄" title="Windows Update Policy" sub="Control how Windows downloads and installs updates" />
            <div className="grid gap-4 max-w-2xl">
              {UPDATE_OPTIONS.map(opt => (
                <div key={opt.id} title={opt.desc}
                     onClick={() => {
                       if (opt.id === 'disable') { setUpdateWarning(true); return }
                       setUpdatePolicy(opt.id)
                       addLog('INFO', `Update policy set to: ${opt.title}`)
                     }}
                     className={`${cardBase}`}
                     style={{
                       background:  updatePolicy === opt.id ? C.surface2 : C.surface,
                       borderColor: updatePolicy === opt.id ? opt.color   : C.border,
                       boxShadow:   updatePolicy === opt.id ? `0 0 14px ${opt.color}44` : 'none',
                     }}>
                  <div className="flex items-center gap-4">
                    <span className="text-2xl">{opt.icon}</span>
                    <div className="flex-1">
                      <div className="font-bold" style={{ color: updatePolicy === opt.id ? opt.color : C.text }}>{opt.title}</div>
                      <div className="text-xs mt-0.5" style={{ color: C.textDim }}>{opt.sub}</div>
                      <div className="text-xs mt-1.5 leading-relaxed" style={{ color: C.textDim }}>{opt.desc}</div>
                    </div>
                    <div className="w-5 h-5 rounded-full border flex items-center justify-center shrink-0"
                         style={{ borderColor: opt.color }}>
                      {updatePolicy === opt.id && <div className="w-3 h-3 rounded-full" style={{ background: opt.color }} />}
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Disable warning dialog */}
            {updateWarning && (
              <div className="fixed inset-0 z-50 flex items-center justify-center" style={{ background: 'rgba(0,0,0,0.8)' }}>
                <div className="p-6 rounded-xl border max-w-md w-full mx-4" style={{ background: C.surface, borderColor: C.err }}>
                  <div className="text-lg font-bold mb-2" style={{ color: C.err }}>⛔ Warning: Disable Windows Updates</div>
                  <div className="text-sm mb-4" style={{ color: C.textDim }}>
                    Disabling Windows Updates means your system will <strong style={{ color: C.text }}>NOT receive security patches</strong>.
                    This can leave you vulnerable to exploits. Only do this if you manage updates via WSUS, SCCM, or manually.
                  </div>
                  <div className="flex gap-3">
                    <button onClick={() => { setUpdatePolicy('disable'); setUpdateWarning(false); addLog('WARN', 'Update policy: DISABLED — ensure you apply security patches manually!') }}
                            className="flex-1 py-2 rounded font-bold text-sm" style={{ background: C.err, color: '#fff' }}>
                      I Understand — Disable
                    </button>
                    <button onClick={() => setUpdateWarning(false)}
                            className="flex-1 py-2 rounded font-bold text-sm border" style={{ borderColor: C.border, color: C.textDim }}>
                      Cancel
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {/* ════════════════════════ MICROWIN ════════════════════════ */}
        {tab === 'microwin' && (
          <div>
            <SectionHeader icon="💿" title="MicroWin — ISO Debloater" sub="Strip Windows bloatware from an ISO before installation" />

            <div className="max-w-2xl space-y-4">
              <div className="p-4 rounded-lg border text-sm" style={{ background: C.surface, borderColor: C.border }}>
                <div className="font-bold mb-2" style={{ color: C.accent }}>How MicroWin Works</div>
                <div style={{ color: C.textDim }} className="text-xs leading-relaxed space-y-1">
                  <p>1. Mounts your Windows ISO and extracts install.wim</p>
                  <p>2. Uses DISM to remove provisioned AppX packages before first boot</p>
                  <p>3. Applies registry tweaks to the offline image</p>
                  <p>4. Unmounts and saves the modified WIM — use Rufus to rebuild the bootable USB</p>
                </div>
              </div>

              <div className="p-4 rounded-lg border space-y-3" style={{ background: C.surface, borderColor: C.border }}>
                <div className="font-bold" style={{ color: C.text }}>Debloat Options</div>
                {Object.entries({
                  removeXbox:        { label: 'Remove Xbox Apps',              desc: 'Removes Xbox Game Bar, Identity, Overlay from the offline image' },
                  removeOneDrive:    { label: 'Remove OneDrive',               desc: 'Prevents OneDrive from being installed during setup' },
                  removeTeams:       { label: 'Remove Consumer Teams',         desc: 'Removes pre-installed Teams consumer app (not enterprise)' },
                  removeBloat:       { label: 'Remove Common Bloatware',       desc: 'Candy Crush, TikTok, Disney+, Solitaire, Bing apps, etc.' },
                  disableTelemetry:  { label: 'Disable Telemetry in Image',    desc: 'Sets AllowTelemetry=0 in the offline registry hive' },
                  addNET3:           { label: 'Add .NET 3.5 Framework',        desc: 'Injects .NET 3.5 from the ISO sources — needed for some older apps' },
                  disableDefender:   { label: '⚠️ Disable Windows Defender',  desc: 'WARNING: Removes Defender from the image. Only for air-gapped/lab PCs.' },
                }).map(([key, { label, desc }]) => (
                  <label key={key} title={desc}
                         className="flex items-center gap-3 cursor-pointer group rounded p-2 transition-all hover:bg-white/5">
                    <input type="checkbox"
                           checked={microwinOpts[key as keyof typeof microwinOpts]}
                           onChange={e => setMicrowinOpts(prev => ({ ...prev, [key]: e.target.checked }))}
                           className="w-4 h-4 accent-cyan-400" />
                    <div>
                      <div className="text-sm font-semibold" style={{ color: key === 'disableDefender' ? C.err : C.text }}>{label}</div>
                      <div className="text-xs" style={{ color: C.textDim }}>{desc}</div>
                    </div>
                  </label>
                ))}
              </div>

              <div className="flex items-center gap-3">
                <button onClick={() => { setMicrowinEnabled(true); addLog('OK', 'MicroWin enabled — ISO debloat script will be included in output.'); addLog('INFO', 'Run the generated script and provide your ISO path when prompted.') }}
                        className="px-5 py-2.5 rounded font-bold text-sm transition-all hover:scale-105"
                        style={{ background: C.accent, color: C.bg }}>
                  💿 Enable MicroWin in Script
                </button>
                {microwinEnabled && (
                  <span className="text-sm font-semibold" style={{ color: C.ok }}>✓ MicroWin included in generated script</span>
                )}
              </div>
            </div>
          </div>
        )}

      </main>

      {/* ── LOG WINDOW ── */}
      <footer className="shrink-0 border-t" style={{ background: C.logBg, borderColor: C.border, height: '180px' }}>
        <div className="flex items-center gap-2 px-4 py-1.5 border-b" style={{ borderColor: C.border }}>
          <span className="text-xs font-bold" style={{ color: C.accent }}>▶ ACTIVITY LOG</span>
          <span className="text-xs ml-auto" style={{ color: C.textDim }}>{logs.length} entries</span>
          <button onClick={() => setLogs([mkLog('INFO', 'Log cleared.')])}
                  className="text-xs px-2 py-0.5 rounded transition-all hover:brightness-125"
                  style={{ background: C.surface, color: C.textDim, border: `1px solid ${C.border}` }}>
            Clear
          </button>
        </div>
        <div className="overflow-y-auto h-[138px] px-4 py-2 space-y-0.5 font-mono text-xs">
          {logs.map(log => (
            <div key={log.id} className="flex gap-2 leading-5">
              <span style={{ color: C.textDim }} className="shrink-0">{log.ts}</span>
              <span className="shrink-0 font-bold w-10" style={{ color: LOG_COLOURS[log.type] }}>
                [{log.type}]
              </span>
              <span style={{ color: log.type === 'OK' ? C.ok : log.type === 'ERR' ? C.err : log.type === 'WARN' ? C.warn : log.type === 'ACTION' ? '#BF5FFF' : C.text }}>
                {log.msg}
              </span>
            </div>
          ))}
          <div ref={logEndRef} />
        </div>
      </footer>

      {/* ── SCRIPT MODAL ── */}
      {scriptModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4"
             style={{ background: 'rgba(0,0,0,0.85)' }}>
          <div className="flex flex-col w-full max-w-4xl rounded-xl border overflow-hidden"
               style={{ background: C.surface, borderColor: C.accent, maxHeight: '90vh', boxShadow: `0 0 40px rgba(0,217,255,0.3)` }}>
            {/* Modal header */}
            <div className="flex items-center gap-3 px-6 py-4 border-b shrink-0"
                 style={{ background: C.navBg, borderColor: C.border }}>
              <span style={{ color: C.accent }} className="font-bold">⚡ RaysOptimizationChamber.ps1</span>
              <span className="text-xs ml-2" style={{ color: C.textDim }}>
                {scriptText.split('\n').length} lines · Run as Administrator
              </span>
              <div className="ml-auto flex gap-2">
                <button onClick={copyScript}
                        className="px-4 py-1.5 rounded text-xs font-bold border transition-all hover:brightness-110"
                        style={{ borderColor: C.accent, color: C.accent, background: 'transparent' }}>
                  📋 Copy
                </button>
                <button onClick={downloadScript}
                        className="px-4 py-1.5 rounded text-xs font-bold transition-all hover:scale-105"
                        style={{ background: C.accent, color: C.bg }}>
                  ⬇ Download .ps1
                </button>
                <button onClick={() => setScriptModal(false)}
                        className="px-3 py-1.5 rounded text-xs font-bold border transition-all hover:brightness-110"
                        style={{ borderColor: C.border, color: C.textDim }}>
                  ✕ Close
                </button>
              </div>
            </div>
            {/* Script content */}
            <div className="flex-1 overflow-auto p-4" style={{ background: C.logBg }}>
              <pre className="text-xs leading-5 whitespace-pre font-mono" style={{ color: C.text }}>
                {scriptText}
              </pre>
            </div>
            {/* Modal footer */}
            <div className="px-6 py-3 border-t text-xs flex items-center gap-3" style={{ borderColor: C.border, color: C.textDim }}>
              <span style={{ color: C.warn }}>⚠️</span>
              <span>Right-click the .ps1 file → "Run as Administrator". Set execution policy if needed:
                <code className="ml-1 px-1 rounded" style={{ background: C.surface2, color: C.accent }}>
                  Set-ExecutionPolicy Bypass -Scope Process
                </code>
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// ── Reusable section header ────────────────────────────────────────────────────
function SectionHeader({ icon, title, sub }: { icon: string; title: string; sub: string }) {
  return (
    <div className="mb-5">
      <div className="flex items-center gap-2 mb-1">
        <span className="text-xl">{icon}</span>
        <h2 className="text-lg font-bold" style={{ color: '#E8F0F8' }}>{title}</h2>
      </div>
      <p className="text-xs" style={{ color: '#8090A0' }}>{sub}</p>
      <div className="mt-2 h-px" style={{ background: 'linear-gradient(to right, #00D9FF44, transparent)' }} />
    </div>
  )
}
