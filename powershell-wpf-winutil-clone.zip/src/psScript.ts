// src/psScript.ts — Ray's Optimization Chamber Engine

export interface AppItem {
  id: string
  name: string
  winget: string
  category: string
  desc: string
  checked?: boolean
}

export interface TweakItem {
  id: string
  label: string
  tag: string
  desc: string
  group: string
  lowEnd?: boolean
  checked?: boolean
}

export const APP_CATALOGUE: AppItem[] = [
  // Browsers
  { id: 'chrome',    name: 'Google Chrome',    winget: 'Google.Chrome',              category: 'Browser',     desc: 'Fast, widely-used browser by Google' },
  { id: 'firefox',   name: 'Firefox',          winget: 'Mozilla.Firefox',            category: 'Browser',     desc: 'Open-source browser by Mozilla' },
  { id: 'brave',     name: 'Brave Browser',    winget: 'Brave.Brave',                category: 'Browser',     desc: 'Privacy-first Chromium browser' },
  { id: 'edge',      name: 'Microsoft Edge',   winget: 'Microsoft.Edge',             category: 'Browser',     desc: 'Microsoft\'s built-in Chromium browser' },
  // Communication
  { id: 'discord',   name: 'Discord',          winget: 'Discord.Discord',            category: 'Communication', desc: 'Voice, video and text chat for gamers' },
  { id: 'slack',     name: 'Slack',            winget: 'SlackTechnologies.Slack',    category: 'Communication', desc: 'Team messaging and collaboration' },
  { id: 'telegram',  name: 'Telegram',         winget: 'Telegram.TelegramDesktop',  category: 'Communication', desc: 'Fast, secure cloud-based messaging' },
  { id: 'zoom',      name: 'Zoom',             winget: 'Zoom.Zoom',                  category: 'Communication', desc: 'Video conferencing and meetings' },
  // Gaming
  { id: 'steam',     name: 'Steam',            winget: 'Valve.Steam',                category: 'Gaming',      desc: 'Valve\'s PC gaming platform' },
  { id: 'epicgames', name: 'Epic Games',       winget: 'EpicGames.EpicGamesLauncher', category: 'Gaming',    desc: 'Epic\'s game store and launcher' },
  { id: 'gog',       name: 'GOG Galaxy',       winget: 'GOG.Galaxy',                 category: 'Gaming',      desc: 'DRM-free game library by GOG' },
  { id: 'msi_ab',   name: 'MSI Afterburner',   winget: 'Guru3D.Afterburner',         category: 'Gaming',      desc: 'GPU overclocking and monitoring' },
  // Dev Tools
  { id: 'vscode',    name: 'VS Code',          winget: 'Microsoft.VisualStudioCode', category: 'Dev',         desc: 'Lightweight, powerful code editor' },
  { id: 'git',       name: 'Git',              winget: 'Git.Git',                    category: 'Dev',         desc: 'Distributed version control system' },
  { id: 'nodejs',    name: 'Node.js LTS',      winget: 'OpenJS.NodeJS.LTS',          category: 'Dev',         desc: 'JavaScript runtime for servers/tools' },
  { id: 'python',    name: 'Python 3',         winget: 'Python.Python.3.12',         category: 'Dev',         desc: 'General-purpose scripting language' },
  { id: 'wt',        name: 'Windows Terminal', winget: 'Microsoft.WindowsTerminal',  category: 'Dev',         desc: 'Modern terminal with tabs and themes' },
  { id: 'powertoys', name: 'PowerToys',        winget: 'Microsoft.PowerToys',        category: 'Dev',         desc: 'Power-user utilities by Microsoft' },
  // Media
  { id: 'vlc',       name: 'VLC',              winget: 'VideoLAN.VLC',               category: 'Media',       desc: 'Open-source multimedia player' },
  { id: 'obs',       name: 'OBS Studio',       winget: 'OBSProject.OBSStudio',       category: 'Media',       desc: 'Free streaming and recording software' },
  { id: 'spotify',   name: 'Spotify',          winget: 'Spotify.Spotify',            category: 'Media',       desc: 'Music streaming service' },
  { id: 'handbrake', name: 'HandBrake',        winget: 'HandBrake.HandBrake',        category: 'Media',       desc: 'Open-source video transcoder' },
  // Utilities
  { id: '7zip',      name: '7-Zip',            winget: '7zip.7zip',                  category: 'Utility',     desc: 'High-compression file archiver' },
  { id: 'notepadpp', name: 'Notepad++',        winget: 'Notepad++.Notepad++',        category: 'Utility',     desc: 'Feature-rich text/code editor' },
  { id: 'everything',name: 'Everything',       winget: 'voidtools.Everything',       category: 'Utility',     desc: 'Instant file search for Windows' },
  { id: 'hwinfo',    name: 'HWiNFO64',         winget: 'REALiX.HWiNFO',             category: 'Utility',     desc: 'In-depth hardware monitoring tool' },
  { id: 'crystaldisk',name:'CrystalDiskInfo',  winget: 'CrystalDewWorld.CrystalDiskInfo', category:'Utility', desc:'Monitors hard drive health (S.M.A.R.T.)'},
  { id: 'rufus',     name: 'Rufus',            winget: 'Rufus.Rufus',                category: 'Utility',     desc: 'Creates bootable USB drives from ISOs' },
  // Security
  { id: 'malwarebytes', name:'Malwarebytes',   winget: 'Malwarebytes.Malwarebytes',  category: 'Security',    desc: 'Anti-malware scanner and real-time protection' },
  { id: 'bitwarden', name: 'Bitwarden',        winget: 'Bitwarden.Bitwarden',        category: 'Security',    desc: 'Open-source password manager' },
  { id: 'treesizefree',name:'TreeSize Free',   winget: 'JAMSoftware.TreeSize.Free',  category: 'Utility',     desc: 'Visual disk space analyzer' },
  { id: 'autoruns',  name: 'Autoruns',         winget: 'Microsoft.Sysinternals.Autoruns', category:'Security', desc:'Shows all startup programs and drivers'},
]

export const TWEAK_CATALOGUE: TweakItem[] = [
  // General / Desktop
  { id:'disable_telemetry', label:'Disable Telemetry',        tag:'Privacy',    group:'General', lowEnd:true,  desc:'Turns off Windows data collection & diagnostic reporting sent to Microsoft.' },
  { id:'disable_cortana',   label:'Disable Cortana',          tag:'Privacy',    group:'General', lowEnd:true,  desc:'Disables Cortana assistant and its background indexing to free CPU/RAM.' },
  { id:'disable_tips',      label:'Disable Tips & Ads',       tag:'Declutter',  group:'General', lowEnd:true,  desc:'Removes lock screen ads, Start menu suggestions, and notification tips.' },
  { id:'dark_mode',         label:'Enable Dark Mode',         tag:'Visual',     group:'General',               desc:'Switches Windows apps and shell to dark theme system-wide.' },
  { id:'show_extensions',   label:'Show File Extensions',     tag:'Explorer',   group:'General',               desc:'Makes Explorer show .exe, .txt etc. so you always know what a file is.' },
  { id:'disable_search_idx',label:'Disable Search Indexing',  tag:'Performance',group:'General', lowEnd:true,  desc:'Stops Windows indexing files in the background, reducing disk and CPU use on HDDs.' },
  // RAM
  { id:'disable_superfetch',label:'Disable SysMain/Superfetch',tag:'RAM',       group:'RAM',     lowEnd:true,  desc:'Stops pre-loading apps into RAM. Recommended for SSDs and low-RAM systems.' },
  { id:'large_sys_cache',   label:'Optimize System Cache',    tag:'RAM',        group:'RAM',                   desc:'Sets LargeSystemCache=0 so Windows prioritizes app memory over file cache.' },
  { id:'clear_standby',     label:'Clear Standby RAM',        tag:'RAM',        group:'RAM',                   desc:'Flushes standby memory list, immediately freeing cached RAM back to apps.' },
  { id:'page_file_auto',    label:'Auto-Manage Page File',    tag:'RAM',        group:'RAM',                   desc:'Lets Windows manage virtual memory size automatically for best stability.' },
  // Power
  { id:'high_perf',         label:'High Performance Plan',    tag:'Power',      group:'Power',   lowEnd:false, desc:'Prevents CPU/GPU from throttling clock speeds. Increases power draw on laptops.' },
  { id:'ultimate_perf',     label:'Ultimate Performance Plan',tag:'Power',      group:'Power',                 desc:'Unlocks hidden plan that disables ALL core parking and power-saving throttles.' },
  { id:'disable_usb_suspend',label:'Disable USB Suspend',     tag:'Power',      group:'Power',                 desc:'Prevents USB ports from sleeping. Stops mice/headsets from cutting out.' },
  { id:'disable_hibernate', label:'Disable Hibernation',      tag:'Power',      group:'Power',   lowEnd:true,  desc:'Removes hiberfil.sys, freeing several GB of disk space. Disables hibernate mode.' },
  // CPU / GPU
  { id:'win32_priority',    label:'Win32 Priority Separation',tag:'CPU',        group:'CPU/GPU',               desc:'Sets foreground app CPU priority to maximum (0x26 hex). Reduces micro-stutters.' },
  { id:'disable_core_park', label:'Disable Core Parking',     tag:'CPU',        group:'CPU/GPU',               desc:'Forces all CPU cores to stay active. Prevents spin-up latency during load spikes.' },
  { id:'gpu_sched',         label:'Hardware GPU Scheduling',  tag:'GPU',        group:'CPU/GPU',               desc:'Enables HAGS (HwSchMode=2) — reduces CPU overhead for GPU tasks on Win10 2004+.' },
  { id:'disable_fth',       label:'Disable Fault Tolerant Heap',tag:'CPU',      group:'CPU/GPU',               desc:'Stops Windows from throttling apps that crash frequently. Better for games.' },
  // Gaming
  { id:'game_mode',         label:'Enable Game Mode',         tag:'Gaming',     group:'Gaming',                desc:'Prioritizes CPU/GPU resources to the active game window.' },
  { id:'disable_nagle',     label:'Disable Nagle\'s Algorithm',tag:'Network',   group:'Gaming',                desc:'Sends TCP packets immediately instead of buffering. Reduces online game latency.' },
  { id:'platform_tick',     label:'Platform Clock Ticks',     tag:'Gaming',     group:'Gaming',                desc:'bcdedit useplatformtick=yes. Forces consistent timer for audio/video sync.' },
  { id:'mmu_gaming',        label:'MMCSS Gaming Profile',     tag:'Gaming',     group:'Gaming',                desc:'Tells Multimedia Class Scheduler to give games high-priority CPU scheduling.' },
  // Network
  { id:'net_throttle_off',  label:'Disable Net Throttling',   tag:'Network',    group:'Network',               desc:'Sets NetworkThrottlingIndex=0xFFFFFFFF — removes bandwidth cap on games/streams.' },
  { id:'tcp_autotuning',    label:'TCP Auto-Tuning Normal',   tag:'Network',    group:'Network',               desc:'Ensures TCP receive window scaling is enabled for optimal throughput.' },
  { id:'ipv6_disable',      label:'Disable IPv6',             tag:'Network',    group:'Network',               desc:'Disables IPv6 stack if you only use IPv4. Can improve DNS resolution speed.' },
  { id:'net_refresh',       label:'Network Stack Refresh',    tag:'Network',    group:'Network',               desc:'Flushes DNS, resets Winsock & IP stack. Fixes most internet connection issues.' },
  // Keyboard / Mouse
  { id:'mouse_accel_off',   label:'Disable Mouse Acceleration',tag:'Input',     group:'Input',                 desc:'Removes "enhance pointer precision" — gives raw, 1:1 mouse movement for aiming.' },
  { id:'kb_repeat_fast',    label:'Fast Keyboard Repeat',     tag:'Input',      group:'Input',                 desc:'Sets keyboard repeat delay/rate to maximum for snappier key response.' },
  { id:'raw_mouse_input',   label:'Enable Raw Mouse Input',   tag:'Input',      group:'Input',                 desc:'Forces games to use DirectInput raw data, bypassing Windows pointer acceleration.' },
  // Cleanup / Storage
  { id:'clean_temp',        label:'Clean Temp Files',         tag:'Cleanup',    group:'Cleanup', lowEnd:true,  desc:'Deletes %TEMP%, C:\\Windows\\Temp, and empties Recycle Bin safely.' },
  { id:'disable_prefetch',  label:'Disable Prefetch (SSD)',   tag:'Storage',    group:'Cleanup',               desc:'Turns off Prefetch/Superfetch on SSDs where it provides no benefit.' },
  { id:'trim_ssd',          label:'Enable SSD TRIM',          tag:'Storage',    group:'Cleanup',               desc:'Ensures TRIM is active so the SSD controller can garbage-collect efficiently.' },
  { id:'disable_83names',   label:'Disable 8.3 Filenames',    tag:'Storage',    group:'Cleanup', lowEnd:true,  desc:'Stops NTFS generating short 8.3 aliases for every file. Speeds up directory ops.' },
  { id:'disable_lastaccess',label:'Disable Last Access Time', tag:'Storage',    group:'Cleanup', lowEnd:true,  desc:'Stops NTFS updating the "last accessed" timestamp on every file read. Reduces I/O.' },
  // Debloat
  { id:'remove_xbox',       label:'Remove Xbox Apps',         tag:'Debloat',    group:'Debloat',               desc:'Uninstalls Xbox Game Bar, Identity, GameOverlay. Does NOT affect Xbox controller support.' },
  { id:'remove_onedrive',   label:'Remove OneDrive',          tag:'Debloat',    group:'Debloat',               desc:'Silently uninstalls OneDrive and removes its shell integration entries.' },
  { id:'remove_teams',      label:'Remove Teams (Consumer)',  tag:'Debloat',    group:'Debloat',               desc:'Removes the consumer-grade Teams app pre-installed on Windows 11. Not Teams Work.' },
  { id:'remove_bloat',      label:'Remove Common Bloatware',  tag:'Debloat',    group:'Debloat', lowEnd:true,  desc:'Removes Candy Crush, TikTok, Disney+, Solitaire Collection, and other sponsored apps.' },
]

// ─── PowerShell Script Generator ─────────────────────────────────────────────

function psLine(...lines: string[]): string {
  return lines.join('\n')
}

export function generatePSScript(
  apps: AppItem[],
  tweakIds: string[],
  updatePolicy: string,
  microwinEnabled: boolean
): string {
  const selected = apps.filter(a => a.checked)
  const hasTweak = (id: string) => tweakIds.includes(id)

  const blocks: string[] = []

  // ── Header ──────────────────────────────────────────────────────────────────
  blocks.push(psLine(
    '#Requires -RunAsAdministrator',
    '<#',
    '.SYNOPSIS',
    "  Ray's Optimization Chamber — WinUtil Pro",
    '  Generated by the Web UI. Run as Administrator.',
    '.VERSION 3.0',
    '#>',
    '',
    '$ErrorActionPreference = "SilentlyContinue"',
    '$ProgressPreference    = "SilentlyContinue"',
    '',
    '# ── Colour-coded logger ────────────────────────────────────────────────────',
    'function Write-Log {',
    '  param([string]$Msg, [string]$Type = "INFO")',
    '  $colours = @{ INFO="Cyan"; OK="Green"; WARN="Yellow"; ERR="Red"; ACTION="Magenta" }',
    '  $prefix  = @{ INFO="[*]"; OK="[+]"; WARN="[!]"; ERR="[X]"; ACTION="[>]" }',
    '  Write-Host "$($prefix[$Type]) $Msg" -ForegroundColor $colours[$Type]',
    '}',
    '',
    '# ── DWM Mica/Acrylic helper ────────────────────────────────────────────────',
    'Add-Type -TypeDefinition @\'',
    'using System;',
    'using System.Runtime.InteropServices;',
    'public static class DwmHelper {',
    '    [DllImport("dwmapi.dll")] public static extern int DwmSetWindowAttribute(IntPtr hwnd, int attr, ref int val, int size);',
    '    public static void SetMica(IntPtr hwnd) {',
    '        int v = 2; DwmSetWindowAttribute(hwnd, 38, ref v, sizeof(int));  // DWMWA_SYSTEMBACKDROP_TYPE Mica',
    '        int dark = 1; DwmSetWindowAttribute(hwnd, 20, ref dark, sizeof(int)); // DWMWA_USE_IMMERSIVE_DARK_MODE',
    '    }',
    '}',
    '\'@ -Language CSharp',
    ''
  ))

  // ── Safety Restore Point ────────────────────────────────────────────────────
  blocks.push(psLine(
    '# ── Safety: Create System Restore Point ───────────────────────────────────',
    'Write-Log "Creating System Restore Point — please wait..." ACTION',
    'Enable-ComputerRestore -Drive "C:\\" -ErrorAction SilentlyContinue',
    'Checkpoint-Computer -Description "RaysOptimizationChamber_$(Get-Date -f yyyyMMdd_HHmmss)" -RestorePointType MODIFY_SETTINGS',
    'Write-Log "Restore Point created successfully." OK',
    ''
  ))

  // ── Registry backup helper ──────────────────────────────────────────────────
  blocks.push(psLine(
    '# ── Registry Safety Vault (backup before every change) ────────────────────',
    '$VaultPath = "$env:USERPROFILE\\RaysVault_$(Get-Date -f yyyyMMdd_HHmmss).reg"',
    'Write-Log "Exporting registry snapshot to $VaultPath" INFO',
    'reg export HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion $VaultPath /y | Out-Null',
    ''
  ))

  // ── Tweaks ──────────────────────────────────────────────────────────────────
  if (tweakIds.length > 0) {
    blocks.push('# ── Tweaks ─────────────────────────────────────────────────────────────────')

    if (hasTweak('disable_telemetry')) blocks.push(psLine(
      'Write-Log "Disabling Telemetry & DiagTrack..." ACTION',
      'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection" -Name "AllowTelemetry" -Value 0 -Force',
      'Stop-Service -Name DiagTrack -Force; Set-Service -Name DiagTrack -StartupType Disabled',
      'Write-Log "Telemetry disabled." OK', ''
    ))

    if (hasTweak('disable_cortana')) blocks.push(psLine(
      'Write-Log "Disabling Cortana..." ACTION',
      'New-Item -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search" -Force | Out-Null',
      'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\Windows Search" -Name "AllowCortana" -Value 0',
      'Write-Log "Cortana disabled." OK', ''
    ))

    if (hasTweak('disable_tips')) blocks.push(psLine(
      'Write-Log "Disabling Tips, Ads & Suggestions..." ACTION',
      'Set-ItemProperty -Path "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" -Name "SubscribedContent-338389Enabled" -Value 0',
      'Set-ItemProperty -Path "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" -Name "SystemPaneSuggestionsEnabled" -Value 0',
      'Set-ItemProperty -Path "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\ContentDeliveryManager" -Name "SoftLandingEnabled" -Value 0',
      'Write-Log "Tips and ads disabled." OK', ''
    ))

    if (hasTweak('dark_mode')) blocks.push(psLine(
      'Write-Log "Enabling Dark Mode..." ACTION',
      'Set-ItemProperty -Path "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" -Name "AppsUseLightTheme" -Value 0',
      'Set-ItemProperty -Path "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Themes\\Personalize" -Name "SystemUsesLightTheme" -Value 0',
      'Write-Log "Dark mode enabled." OK', ''
    ))

    if (hasTweak('show_extensions')) blocks.push(psLine(
      'Write-Log "Showing file extensions in Explorer..." ACTION',
      'Set-ItemProperty -Path "HKCU:\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced" -Name "HideFileExt" -Value 0',
      'Write-Log "File extensions visible." OK', ''
    ))

    if (hasTweak('disable_search_idx')) blocks.push(psLine(
      'Write-Log "Disabling Windows Search Indexing..." ACTION',
      'Stop-Service -Name WSearch -Force; Set-Service -Name WSearch -StartupType Disabled',
      'Write-Log "Search indexing disabled." OK', ''
    ))

    if (hasTweak('disable_superfetch')) blocks.push(psLine(
      'Write-Log "Disabling SysMain (Superfetch)..." ACTION',
      'Stop-Service -Name SysMain -Force; Set-Service -Name SysMain -StartupType Disabled',
      'Write-Log "SysMain disabled." OK', ''
    ))

    if (hasTweak('large_sys_cache')) blocks.push(psLine(
      'Write-Log "Optimizing System Cache for apps..." ACTION',
      'Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management" -Name "LargeSystemCache" -Value 0',
      'Write-Log "System cache optimized." OK', ''
    ))

    if (hasTweak('clear_standby')) blocks.push(psLine(
      'Write-Log "Clearing Standby RAM list..." ACTION',
      '$code = @"',
      'using System; using System.Runtime.InteropServices;',
      'public class MemClear { [DllImport("ntdll.dll")] public static extern int NtSetSystemInformation(int cls,IntPtr inf,int len);',
      '  public static void Clear(){ var v=IntPtr.Zero; NtSetSystemInformation(80,v,0); } }',
      '"@',
      'Add-Type -TypeDefinition $code; [MemClear]::Clear()',
      'Write-Log "Standby RAM cleared." OK', ''
    ))

    if (hasTweak('high_perf')) blocks.push(psLine(
      'Write-Log "Activating High Performance power plan..." ACTION',
      'powercfg -setactive SCHEME_MIN',
      'Write-Log "High Performance plan active." OK', ''
    ))

    if (hasTweak('ultimate_perf')) blocks.push(psLine(
      'Write-Log "Unlocking Ultimate Performance power plan..." ACTION',
      'powercfg -duplicatescheme e9a42b02-d5df-448d-aa00-03f14749eb61',
      '$guid = (powercfg -list | Select-String "Ultimate").ToString().Split()[3]',
      'if ($guid) { powercfg -setactive $guid; Write-Log "Ultimate Performance plan active: $guid" OK }',
      'else { Write-Log "Could not locate Ultimate Performance GUID." WARN }', ''
    ))

    if (hasTweak('disable_usb_suspend')) blocks.push(psLine(
      'Write-Log "Disabling USB Selective Suspend..." ACTION',
      'powercfg -setacvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0',
      'powercfg -setdcvalueindex SCHEME_CURRENT 2a737441-1930-4402-8d77-b2bebba308a3 48e6b7a6-50f5-4782-a5d4-53bb8f07e226 0',
      'powercfg -setactive SCHEME_CURRENT',
      'Write-Log "USB Selective Suspend disabled." OK', ''
    ))

    if (hasTweak('disable_hibernate')) blocks.push(psLine(
      'Write-Log "Disabling Hibernation to free disk space..." ACTION',
      'powercfg -h off',
      'Write-Log "Hibernation disabled. hiberfil.sys removed." OK', ''
    ))

    if (hasTweak('win32_priority')) blocks.push(psLine(
      'Write-Log "Setting Win32PrioritySeparation for foreground boost..." ACTION',
      'Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl" -Name "Win32PrioritySeparation" -Value 0x26',
      'Write-Log "Win32PrioritySeparation set to 0x26." OK', ''
    ))

    if (hasTweak('disable_core_park')) blocks.push(psLine(
      'Write-Log "Disabling CPU Core Parking..." ACTION',
      '$cpuPark = "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Power\\PowerSettings\\54533251-82be-4824-96c1-47b60b740d00\\0cc5b647-c1df-4637-891a-dec35c318583"',
      'Set-ItemProperty -Path $cpuPark -Name "ValueMax" -Value 0',
      'Write-Log "Core parking disabled." OK', ''
    ))

    if (hasTweak('gpu_sched')) blocks.push(psLine(
      'Write-Log "Enabling Hardware GPU Scheduling..." ACTION',
      'Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" -Name "HwSchMode" -Value 2',
      'Write-Log "HAGS enabled. Reboot required." OK', ''
    ))

    if (hasTweak('disable_fth')) blocks.push(psLine(
      'Write-Log "Disabling Fault Tolerant Heap..." ACTION',
      'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\FTH" -Name "Enabled" -Value 0',
      'Write-Log "FTH disabled." OK', ''
    ))

    if (hasTweak('game_mode')) blocks.push(psLine(
      'Write-Log "Enabling Windows Game Mode..." ACTION',
      'Set-ItemProperty -Path "HKCU:\\SOFTWARE\\Microsoft\\GameBar" -Name "AutoGameModeEnabled" -Value 1',
      'Write-Log "Game Mode enabled." OK', ''
    ))

    if (hasTweak('disable_nagle')) blocks.push(psLine(
      'Write-Log "Disabling Nagle Algorithm (TcpAckFrequency)..." ACTION',
      '$adapters = Get-ChildItem "HKLM:\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces"',
      'foreach ($a in $adapters) {',
      '  Set-ItemProperty -Path $a.PSPath -Name "TcpAckFrequency" -Value 1 -ErrorAction SilentlyContinue',
      '  Set-ItemProperty -Path $a.PSPath -Name "TCPNoDelay" -Value 1 -ErrorAction SilentlyContinue',
      '}',
      'Write-Log "Nagle Algorithm disabled on all adapters." OK', ''
    ))

    if (hasTweak('platform_tick')) blocks.push(psLine(
      'Write-Log "Setting platform clock tick policy..." ACTION',
      'bcdedit /set useplatformtick yes',
      'bcdedit /set disabledynamictick yes',
      'Write-Log "Platform tick enabled." OK', ''
    ))

    if (hasTweak('mmu_gaming')) blocks.push(psLine(
      'Write-Log "Configuring MMCSS Gaming profile..." ACTION',
      'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games" -Name "Priority" -Value 6',
      'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile\\Tasks\\Games" -Name "Scheduling Category" -Value "High"',
      'Write-Log "MMCSS Gaming profile configured." OK', ''
    ))

    if (hasTweak('net_throttle_off')) blocks.push(psLine(
      'Write-Log "Disabling Network Throttling Index..." ACTION',
      'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile" -Name "NetworkThrottlingIndex" -Value 0xFFFFFFFF',
      'Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile" -Name "SystemResponsiveness" -Value 10',
      'Write-Log "Network throttling disabled." OK', ''
    ))

    if (hasTweak('tcp_autotuning')) blocks.push(psLine(
      'Write-Log "Setting TCP Auto-Tuning to Normal..." ACTION',
      'netsh int tcp set global autotuninglevel=normal',
      'netsh int tcp set global rss=enabled',
      'Write-Log "TCP Auto-Tuning configured." OK', ''
    ))

    if (hasTweak('ipv6_disable')) blocks.push(psLine(
      'Write-Log "Disabling IPv6..." ACTION',
      'Disable-NetAdapterBinding -Name "*" -ComponentID ms_tcpip6',
      'Write-Log "IPv6 disabled on all adapters." OK', ''
    ))

    if (hasTweak('net_refresh')) blocks.push(psLine(
      'Write-Log "Refreshing Network Stack..." ACTION',
      'ipconfig /release',
      'ipconfig /flushdns',
      'netsh winsock reset',
      'netsh int ip reset',
      'ipconfig /renew',
      'Write-Log "Network stack refreshed. Reboot recommended." OK', ''
    ))

    if (hasTweak('mouse_accel_off')) blocks.push(psLine(
      'Write-Log "Disabling Mouse Acceleration..." ACTION',
      'Set-ItemProperty -Path "HKCU:\\Control Panel\\Mouse" -Name "MouseSpeed" -Value "0"',
      'Set-ItemProperty -Path "HKCU:\\Control Panel\\Mouse" -Name "MouseThreshold1" -Value "0"',
      'Set-ItemProperty -Path "HKCU:\\Control Panel\\Mouse" -Name "MouseThreshold2" -Value "0"',
      'Write-Log "Mouse acceleration disabled." OK', ''
    ))

    if (hasTweak('kb_repeat_fast')) blocks.push(psLine(
      'Write-Log "Setting fast keyboard repeat rate..." ACTION',
      'Set-ItemProperty -Path "HKCU:\\Control Panel\\Keyboard" -Name "KeyboardSpeed" -Value "31"',
      'Set-ItemProperty -Path "HKCU:\\Control Panel\\Keyboard" -Name "KeyboardDelay" -Value "0"',
      'Write-Log "Keyboard repeat rate maximized." OK', ''
    ))

    if (hasTweak('raw_mouse_input')) blocks.push(psLine(
      'Write-Log "Enabling Raw Mouse Input flag..." ACTION',
      'Set-ItemProperty -Path "HKCU:\\Control Panel\\Mouse" -Name "MouseSensitivity" -Value "10"',
      'Write-Log "Raw input pointer set. Configure per-game in game settings." OK', ''
    ))

    if (hasTweak('clean_temp')) blocks.push(psLine(
      'Write-Log "Cleaning Temp files..." ACTION',
      'Remove-Item "$env:TEMP\\*" -Recurse -Force -ErrorAction SilentlyContinue',
      'Remove-Item "C:\\Windows\\Temp\\*" -Recurse -Force -ErrorAction SilentlyContinue',
      'Clear-RecycleBin -Force -ErrorAction SilentlyContinue',
      'Write-Log "Temp files and Recycle Bin cleared." OK', ''
    ))

    if (hasTweak('disable_prefetch')) blocks.push(psLine(
      'Write-Log "Disabling Prefetch for SSD..." ACTION',
      'Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters" -Name "EnablePrefetcher" -Value 0',
      'Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\Session Manager\\Memory Management\\PrefetchParameters" -Name "EnableSuperfetch" -Value 0',
      'Write-Log "Prefetch disabled." OK', ''
    ))

    if (hasTweak('trim_ssd')) blocks.push(psLine(
      'Write-Log "Enabling SSD TRIM..." ACTION',
      'fsutil behavior set DisableDeleteNotify 0',
      'Write-Log "TRIM enabled." OK', ''
    ))

    if (hasTweak('disable_83names')) blocks.push(psLine(
      'Write-Log "Disabling 8.3 short filenames..." ACTION',
      'fsutil behavior set Disable8dot3 1',
      'Write-Log "8.3 filenames disabled." OK', ''
    ))

    if (hasTweak('disable_lastaccess')) blocks.push(psLine(
      'Write-Log "Disabling Last Access timestamp updates..." ACTION',
      'fsutil behavior set disablelastaccess 1',
      'Write-Log "Last access timestamps disabled." OK', ''
    ))

    if (hasTweak('remove_xbox')) blocks.push(psLine(
      'Write-Log "Removing Xbox bloat apps..." ACTION',
      'Get-AppxPackage *Xbox* | Where-Object {$_.Name -ne "Microsoft.GamingServices"} | Remove-AppxPackage -ErrorAction SilentlyContinue',
      'Write-Log "Xbox apps removed. Controller support unaffected." OK', ''
    ))

    if (hasTweak('remove_onedrive')) blocks.push(psLine(
      'Write-Log "Removing OneDrive..." ACTION',
      'Stop-Process -Name OneDrive -Force -ErrorAction SilentlyContinue',
      'Start-Process "$env:SystemRoot\\SysWOW64\\OneDriveSetup.exe" -ArgumentList "/uninstall" -Wait -ErrorAction SilentlyContinue',
      'Start-Process "$env:SystemRoot\\System32\\OneDriveSetup.exe"  -ArgumentList "/uninstall" -Wait -ErrorAction SilentlyContinue',
      'Write-Log "OneDrive removed." OK', ''
    ))

    if (hasTweak('remove_teams')) blocks.push(psLine(
      'Write-Log "Removing Consumer Teams..." ACTION',
      'Get-AppxPackage *Teams* | Where-Object {$_.Name -notlike "*work*"} | Remove-AppxPackage -ErrorAction SilentlyContinue',
      'Write-Log "Consumer Teams removed." OK', ''
    ))

    if (hasTweak('remove_bloat')) blocks.push(psLine(
      'Write-Log "Removing common bloatware..." ACTION',
      '$bloat = @("king.com.CandyCrush*","BytedancePte.TikTok","Disney.37853FC22B2CE","Microsoft.MicrosoftSolitaireCollection","*BubbleWitch*","*Asphalt*","*Netflix*","*Facebook*")',
      'foreach ($pkg in $bloat) { Get-AppxPackage $pkg | Remove-AppxPackage -ErrorAction SilentlyContinue }',
      'Write-Log "Bloatware removed." OK', ''
    ))
  }

  // ── Update Policy ────────────────────────────────────────────────────────────
  if (updatePolicy && updatePolicy !== 'default') {
    blocks.push('# ── Windows Update Policy ───────────────────────────────────────────────────')
    const wuPath = '"HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU"'
    blocks.push('New-Item -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU" -Force | Out-Null')
    if (updatePolicy === 'security') {
      blocks.push(psLine(
        'Write-Log "Setting Windows Update to Security-Only..." ACTION',
        `Set-ItemProperty -Path ${wuPath} -Name "AUOptions" -Value 3`,
        `Set-ItemProperty -Path ${wuPath} -Name "NoAutoUpdate" -Value 0`,
        'Write-Log "Update policy: Security Only." OK', ''
      ))
    } else if (updatePolicy === 'disable') {
      blocks.push(psLine(
        'Write-Log "WARN: Disabling Windows Update (not recommended)..." WARN',
        `Set-ItemProperty -Path ${wuPath} -Name "NoAutoUpdate" -Value 1`,
        'Stop-Service -Name wuauserv -Force; Set-Service -Name wuauserv -StartupType Disabled',
        'Write-Log "Windows Update disabled. Re-enable before installing security patches." WARN', ''
      ))
    }
  }

  // ── App Installation ─────────────────────────────────────────────────────────
  if (selected.length > 0) {
    blocks.push(psLine(
      '# ── App Installation via winget ─────────────────────────────────────────────',
      'Write-Log "Starting app installations..." ACTION',
      ''
    ))
    selected.forEach(app => {
      blocks.push(psLine(
        `Write-Log "Installing ${app.name}..." INFO`,
        `winget install --id ${app.winget} --silent --accept-package-agreements --accept-source-agreements --no-upgrade`,
        `if ($LASTEXITCODE -eq 0) { Write-Log "${app.name} installed successfully." OK }`,
        `else { Write-Log "${app.name} install failed or already installed (exit $LASTEXITCODE)." WARN }`,
        ''
      ))
    })
  }

  // ── MicroWin ─────────────────────────────────────────────────────────────────
  if (microwinEnabled) {
    blocks.push(psLine(
      '# ── MicroWin: ISO Debloat ───────────────────────────────────────────────────',
      'Write-Log "MicroWin: Starting ISO debloat process..." ACTION',
      '$ISOPath    = Read-Host "Enter full path to your Windows ISO"',
      '$OutputPath = Read-Host "Enter output folder for debloated ISO"',
      'if (-not (Test-Path $ISOPath)) { Write-Log "ISO not found: $ISOPath" ERR; exit 1 }',
      '$MountDir = "$env:TEMP\\MicroWin_Mount"',
      'New-Item -ItemType Directory -Path $MountDir -Force | Out-Null',
      'Write-Log "Mounting ISO..." INFO',
      '$mount = Mount-DiskImage -ImagePath $ISOPath -PassThru',
      '$drive = ($mount | Get-Volume).DriveLetter + ":"',
      'Write-Log "ISO mounted at $drive" OK',
      'Write-Log "Copying install.wim..." INFO',
      'Copy-Item "$drive\\sources\\install.wim" "$env:TEMP\\install.wim" -Force',
      'Dism /Mount-Wim /WimFile:"$env:TEMP\\install.wim" /index:1 /MountDir:$MountDir',
      'Write-Log "Removing provisioned bloat packages..." INFO',
      '$bloatPkgs = @("Microsoft.BingWeather","Microsoft.GetHelp","Microsoft.Getstarted","Microsoft.MicrosoftSolitaireCollection","Microsoft.People","Microsoft.WindowsFeedbackHub","Microsoft.Xbox.TCUI","Microsoft.XboxApp","Microsoft.XboxGameOverlay","Microsoft.XboxIdentityProvider","Microsoft.ZuneMusic","Microsoft.ZuneVideo")',
      'foreach ($pkg in $bloatPkgs) { Dism /Image:$MountDir /Remove-ProvisionedAppxPackage /PackageName:$pkg 2>$null }',
      'Write-Log "Committing changes and unmounting..." INFO',
      'Dism /Unmount-Wim /MountDir:$MountDir /Commit',
      'Dismount-DiskImage -ImagePath $ISOPath',
      'Write-Log "MicroWin complete! Modified WIM saved to $env:TEMP\\install.wim" OK',
      'Write-Log "Use Rufus to rebuild the ISO from the modified WIM." INFO', ''
    ))
  }

  // ── System Health Scan ───────────────────────────────────────────────────────
  blocks.push(psLine(
    '# ── System Health Scan (SFC + DISM + WU Reset) ──────────────────────────────',
    'function Invoke-HealthScan {',
    '  Write-Log "Running SFC /scannow — this may take several minutes..." ACTION',
    '  sfc /scannow',
    '  Write-Log "Running DISM /RestoreHealth..." ACTION',
    '  DISM /Online /Cleanup-Image /RestoreHealth',
    '  Write-Log "Resetting Windows Update cache..." ACTION',
    '  Stop-Service -Name wuauserv,bits,cryptsvc -Force',
    '  Remove-Item "$env:SystemRoot\\SoftwareDistribution" -Recurse -Force -ErrorAction SilentlyContinue',
    '  Remove-Item "$env:SystemRoot\\System32\\catroot2" -Recurse -Force -ErrorAction SilentlyContinue',
    '  Start-Service -Name wuauserv,bits,cryptsvc',
    '  Write-Log "Health scan and WU reset complete." OK',
    '}',
    ''
  ))

  // ── Revert / Restore Defaults ────────────────────────────────────────────────
  blocks.push(psLine(
    '# ── Revert All Changes (Restore Windows Defaults) ───────────────────────────',
    'function Revert-AllChanges {',
    '  Write-Log "Reverting all optimizations to Windows defaults..." WARN',
    '  # Network',
    '  netsh int tcp set global autotuninglevel=normal',
    '  netsh int tcp set global rss=enabled',
    '  # Priority',
    '  Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\PriorityControl" -Name "Win32PrioritySeparation" -Value 0x02',
    '  # Multimedia',
    '  Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile" -Name "SystemResponsiveness" -Value 20',
    '  Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Microsoft\\Windows NT\\CurrentVersion\\Multimedia\\SystemProfile" -Name "NetworkThrottlingIndex" -Value 10',
    '  # Mouse',
    '  Set-ItemProperty -Path "HKCU:\\Control Panel\\Mouse" -Name "MouseSpeed" -Value "1"',
    '  Set-ItemProperty -Path "HKCU:\\Control Panel\\Mouse" -Name "MouseThreshold1" -Value "6"',
    '  Set-ItemProperty -Path "HKCU:\\Control Panel\\Mouse" -Name "MouseThreshold2" -Value "10"',
    '  # Telemetry',
    '  Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\DataCollection" -Name "AllowTelemetry" -Value 1',
    '  Start-Service -Name DiagTrack; Set-Service -Name DiagTrack -StartupType Automatic',
    '  # SysMain',
    '  Start-Service -Name SysMain; Set-Service -Name SysMain -StartupType Automatic',
    '  # Power plan back to Balanced',
    '  powercfg -setactive SCHEME_BALANCED',
    '  # BCD',
    '  bcdedit /deletevalue useplatformtick',
    '  bcdedit /deletevalue disabledynamictick',
    '  # GPU Scheduling off',
    '  Set-ItemProperty -Path "HKLM:\\SYSTEM\\CurrentControlSet\\Control\\GraphicsDrivers" -Name "HwSchMode" -Value 1',
    '  # WU back to automatic',
    '  Set-ItemProperty -Path "HKLM:\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate\\AU" -Name "NoAutoUpdate" -Value 0',
    '  Start-Service -Name wuauserv; Set-Service -Name wuauserv -StartupType Automatic',
    '  Write-Log "All changes reverted to Windows defaults. Reboot recommended." OK',
    '}',
    ''
  ))

  // ── Footer ───────────────────────────────────────────────────────────────────
  blocks.push(psLine(
    '# ── Done ────────────────────────────────────────────────────────────────────',
    'Write-Log "=============================================" INFO',
    `Write-Log "Ray's Optimization Chamber — Complete!" OK`,
    'Write-Log "A reboot is recommended for all changes to take effect." WARN',
    'Write-Log "Registry snapshot saved to: $VaultPath" INFO',
    'Write-Log "=============================================" INFO',
    'Read-Host "Press Enter to exit"'
  ))

  return blocks.join('\n')
}
